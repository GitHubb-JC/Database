-- SQLite
create table users (
    first_name text not null,
    last_name text not null,
    age integer not null,
    country text not null,
    phone text not null,
    balance integer not null
);

